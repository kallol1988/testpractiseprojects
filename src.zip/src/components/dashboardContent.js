import React from 'react';
import { Link } from "react-router-dom";
const DashboardContent = () => {
  return (
    <div className="dashboardContentWraper">
      <p>This is the text section</p>
      <Link to="/contact">Contact</Link>
    </div>
    
  );
}

export default DashboardContent;
