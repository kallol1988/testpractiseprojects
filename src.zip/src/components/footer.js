import React from 'react';


  const Footer = () => {
  return (
    
    <footer className="footer">
                <div className="container d-flex">
                    
                    <div className="copyText">
                        <p>&copy; All rights reserved, 2022.</p>
                    </div>
                </div>
            </footer>

  );
}

export default Footer;