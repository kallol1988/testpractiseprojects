import React from 'react';

const ContactContent = () => {
  return (
    <div className="dashboardContentWraper">
      <p>This is the Contact text section</p>
      
    </div>
    
  );
}

export default ContactContent;
