import React from "react";
// import Sidebarfile from './sidebarfile/Sidebarfile';

const LoginPage = () => {
 
  return (
  <div className="loginContainer">
    <div className="loginFormArea">
        <h1>Login</h1>  

                        
        
        <div className="loginForm">
            <div className="formRow fieldRow">
                <label>Email Address</label>
                <input type="text" className="formControl inputField" value="" name="email" id="loginEmail" placeholder="Enter email id" />
            </div>
            <div className="formRow fieldRow">
                <label>Password</label>
                <input type="password" className="formControl inputField" name="password" id="loginPassword" placeholder="Enter password" />
            </div>
            
            <div className="formRow">
                <button type="button" className="blueBtn" id="postLoginInfo">Login</button>
            </div>
        </div>
        
    </div>

    <div class="loginGraphicArea">
     
    </div>

  </div>
  

  );
}

export default LoginPage;
