import React from 'react';
import {Route} from 'react-router-dom';
// import logo from './logo.svg';
// import './App.css';
import './assets/css/defaults.css';
import './assets/css/style.scss';
import LoginPage from './pages/login';
import DashboardPage from './pages/dashboard';
import ContactPage from './pages/contact';

function App() {
  return (
    <>
    <LoginPage />
     {/* <Route path="/">
      <LoginPage />
    </Route> 
     <Route path="/dashboard">
     <DashboardPage />
   </Route>
    <Route path="/contact">
    <ContactPage />
  </Route> */}
  </>
  );
}

export default App;
